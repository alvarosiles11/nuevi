 
<!-- <script src="typewrite.js" type="text/javascript></script> -->
 
  <div
    style="    justify-content: center; align-items: center; display: flex;  " class="bold" 
  >
    <h1 style="font-family: 'Open Sans', sans-serif; font-size: 70px">
      <👋
      <span
        class="typewrite"
        data-period="2000"
        data-type='["Hola","Hello","Salut","Ciao","Olá","Hallo","你好"]'
      > </span  >, world! />
    </h1>
  </div>
 