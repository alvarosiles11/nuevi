# **SO**

 
<div style=" display:flex">
<div > 

* <a href="https://brave.com/es/"><img height="20" src="https://www.ecured.cu/images/9/97/Bravebrowser.png" /></a> Brave

* <a href="https://desktop.github.com/"><img height="20" src="https://desktop.github.com/images/desktop-icon.svg" /></a> GitHub Desktop

* <a href="https://www.sourcetreeapp.com/"><img height="20" src="https://s3.amazonaws.com/s3.roaringapps.com/assets/icons/1561277508424-Source%20Tree.png" /></a> Sourcetree app

* <a href="https://nodejs.org/en/download/"><img height="20" src="https://midu.dev/images/tags/node.png" /></a> Nodejs

* <a href="https://www.mongodb.com/try/download/community"><img height="20" src="https://icons-for-free.com/download-icon-mongodb+original-1324760553088442944_512.png" /></a> MongoDB server

* <a href="https://www.mongodb.com/try/download/compass"><img height="20" src="https://icons-for-free.com/download-icon-mongodb+original-1324760553088442944_512.png" /></a>  MongoDB compass

* <a href="https://code.visualstudio.com/"><img height="20" src="https://sparkcdneus2.azureedge.net/sparkimageassets/XP9KHM4BK9FZ7Q-63e59db4-cf83-46b7-9365-0c37221b94de" /></a> Visual Studio Code
 
    - <img height="20" src="https://ms-ceintl.gallerycdn.vsassets.io/extensions/ms-ceintl/vscode-language-pack-es/1.70.8030927/1659519015836/Microsoft.VisualStudio.Services.Icons.Default" /> Spanish Language

    - <img height="20" src="https://github.gallerycdn.vsassets.io/extensions/github/copilot/1.38.6394/1659530148827/Microsoft.VisualStudio.Services.Icons.Default" /> GitHub Copilot

    - <img height="20" src="https://redhat.gallerycdn.vsassets.io/extensions/redhat/java/1.10.2022080505/1659690497942/Microsoft.VisualStudio.Services.Icons.Default" /> Extension Pack for Java

    - <img height="20" src="https://editorconfig.gallerycdn.vsassets.io/extensions/editorconfig/editorconfig/0.16.4/1607315835386/Microsoft.VisualStudio.Services.Icons.Default" /> EditorConfig 

    - <img height="20" src="https://pkief.gallerycdn.vsassets.io/extensions/pkief/material-icon-theme/4.19.0/1656747111930/Microsoft.VisualStudio.Services.Icons.Default" /> Material Icon Theme 

* <a href="https://insomnia.rest/download"><img height="20" src="https://insomnia.rest/images/insomnia-logo.svg" /></a>

* <a href="https://www.postman.com/downloads/"><img height="20" src="https://iconape.com/wp-content/png_logo_vector/postman.png" /></a> postman

* <a href="https://desktop.telegram.org/"><img height="20" src="https://osx.telegram.org/updates/site/logo.png" /></a> Telegram Desktop

    

</div>
<div >

* <a href="https://www.dprojects.org/minios"><img height="20" src="https://files.softicons.com/download/folder-icons/mac-os-black-folder-icons-by-demcha/png/256x256/Iso.png" /></a> dprojects

    - <a href="https://www.mediafire.com/file/ny5tifybn3x6esv/6ec7c4079516353c7ef7d356a6fc7816.rar/file"><img height="20" src="https://www.unixmen.com/wp-content/uploads/2013/12/iso.png" /></a> Windows10 LTSC 21H2, x64

    - <a href="https://www.mediafire.com/file/nffpb5dw9ay2w6n/fcd46ef7aa06a884d69c49fbd88a65e3.rar/file"><img height="20" src="https://www.unixmen.com/wp-content/uploads/2013/12/iso.png" /></a> windows 11 pro 64 bit iso

    - <a href="https://www.mediafire.com/file/7fx7z9edtksuuq6/MENU_Extendido_v6.4_-_www.dprojects.org.rar/file
    "><img height="20" src="https://www.drunkgaming.net/uploads/monthly_2021_04/unnamed.jpg.ce70f575ed097bb0d35f9fe2ebadd606.jpg" /></a> MENU Extendido

    - <a href="https://dl.360safe.com/drvmgr/gwwk__360DrvMgrInstaller_net.exe"><img height="20" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTu-CfJWAoaAMwtJVtA-78Ivy0oFh2L2_aa1Bg78yQot8YaKyYqj9F5vr2LKh92D2AW7WU&usqp=CAU" /></a> software 360
    - <a href="https://mega.nz/file/LgZ3XBIY#h1ICk9r-qlVDSBblMwRWpRk48l5FHRTOOCRX_ZPAyv4"><img height="20" src="https://stormpoopersmith.com/wp-content/uploads/2012/01/AppLogo-150x150.png" /></a> OEM Brander
    - <a href="https://8gadgetpack.net/"><img height="20" src="https://www.softexia.com/wp-content/uploads/2016/01/8GadgetPack.png" /></a> 8gadgetpack
    - <a href="https://fliqlo.com/screensaver/"><img height="20" src="https://progsoft.net/images/fliqlo-icon-d4ede465ec80850024cba534489a876493a84b65.png" /></a> Fliqlo

    - <a href="https://mega.nz/file/a9IwRbZJ#3AsvlexghpQoNdK-z3RcskAq4XBWdfVcMT-ORUF0MUM"><img height="20" src="https://offlinefreewarefiles.com/wp-content/uploads/2019/02/Directx.png" /></a> DirectX 9

    - <a href="https://mega.nz/file/q05hwSTJ#LJ2LwQfeZc6kJbl-LJfPHRZEN_7P2wTPDogI79cXZJo"><img height="20" src="https://s3.amazonaws.com/cf-nitroengassets-prod/images/sites/gonitro/brand-assets/nitro-logo-dark.png" /></a>  
    - <a href="https://rufus.ie/es/"><img height="20" src="https://rufus.ie/pics/rufus-128.png" /></a> rufus
    - <a href="https://www.winrar.es/descargas/103/descargar-winrar-para-windows-x64-en-espanol"><img height="20" src="https://img.utdstc.com/icon/487/824/4878246f6401efb0b316f39a0a42548e51010cda94db8cf5f71347cbb3dbfc89:200" /></a> WinRAR x64 
    </div>

</div>

    

 

    
